package kr.co.test.mytools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MytoolswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MytoolswebApplication.class, args);
	}

}
