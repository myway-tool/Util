package kr.co.test.mytools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MytoolswebApplicationTests {

	@Test
	void contextLoads() {
	}

}
